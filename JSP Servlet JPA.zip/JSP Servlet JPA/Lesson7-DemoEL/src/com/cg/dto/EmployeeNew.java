package com.cg.dto;

public class EmployeeNew 
{

	private Integer empid;
	private String ename;
	private Double salary;
	private MyDog dog;
	

	public EmployeeNew() {
		super();
		
	}


	public EmployeeNew(Integer empid, String ename, Double salary, MyDog dog) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.salary = salary;
		this.dog = dog;
	}
	
	public Integer getEmpid() {
		return empid;
	}


	public void setEmpid(Integer empid) {
		this.empid = empid;
	}


	public String getEname() {
		return ename;
	}


	public void setEname(String ename) {
		this.ename = ename;
	}


	public Double getSalary() {
		return salary;
	}


	public void setSalary(Double salary) {
		this.salary = salary;
	}


	public MyDog getDog() {
		return dog;
	}


	public void setDog(MyDog dog) {
		this.dog = dog;
	}




	@Override
	public String toString() {
		return "EmployeeNew [empid=" + empid + ", ename=" + ename + ", salary="
				+ salary + ", dog=" + dog + "]";
	}
	
	
}
