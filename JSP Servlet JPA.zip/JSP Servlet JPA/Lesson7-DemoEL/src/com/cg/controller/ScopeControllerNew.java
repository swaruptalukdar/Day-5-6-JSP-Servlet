package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ScopeControllerNew")
public class ScopeControllerNew extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String ename="Ravi";
		String job="Manager";
		String companyName="Capgemini";
		request.setAttribute("ename", ename);
		HttpSession session=request.getSession();
		session.setAttribute("job", job);
		ServletContext context=request.getServletContext();
		context.setAttribute("company", companyName);
		
		RequestDispatcher rd=request.getRequestDispatcher("scopes/scope.jsp");
		rd.forward(request, response);// use for dynamic page resource
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
