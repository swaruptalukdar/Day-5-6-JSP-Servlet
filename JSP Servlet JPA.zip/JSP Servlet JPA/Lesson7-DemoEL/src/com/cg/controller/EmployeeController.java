package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.EmployeeNew;
import com.cg.dto.MyDog;

@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			MyDog dog= new MyDog("nancy","pomeranian");
			EmployeeNew employee=new EmployeeNew(1101, "Smith", 58965.00, dog);
			EmployeeNew employees[]=new EmployeeNew[2];
			employees[0]=new EmployeeNew(1, "Ravi", 58965.00, dog);
			employees[1]=new EmployeeNew(2, "Ravina", 58968.00, dog);
			request.setAttribute("employees", employee);
			request.setAttribute("emp", employee);
			RequestDispatcher rd=request.getRequestDispatcher("object/employee.jsp");
			response.getWriter().println("redirect into jsp");
			rd.include(request, response);
			response.getWriter().println("closing servlet");
			
		}
		catch(Exception e)
		{
			
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
