package com.capg.trg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;

import javax.persistence.Query;

import com.capg.trg.enitity.User;
import com.capg.trg.exception.UserException;
import com.capg.trg.utility.JPAUtil;


public class UserDAOImpl implements IUserDAO {
	EntityManager entityManager=null;

	@Override
	public User getUserDetails(Integer userid) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean isValidUser(String username, String password)
			throws UserException 
	{
		entityManager=JPAUtil.getEntityManager();
		String jql="select u from  User u where u.username=:pname and u.password=:pwd";

		try
		{
			entityManager=JPAUtil.getEntityManager();
			Query query=entityManager.createQuery(jql);
			query.setParameter("pname", username);
			query.setParameter("pwd", password);
			List<User> userList=query.getResultList();
			if(userList.size()==0)
			{
				return false;
			}
			else
			{
				return true;
			}
		}
		catch(PersistenceException e) 
		{
			e.printStackTrace();
			//TODO: Log to file
			throw new UserException();
		}
		finally 
		{
			entityManager.close();
		}
	}

	@Override
	public Integer addUserDetails(User user) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

}
