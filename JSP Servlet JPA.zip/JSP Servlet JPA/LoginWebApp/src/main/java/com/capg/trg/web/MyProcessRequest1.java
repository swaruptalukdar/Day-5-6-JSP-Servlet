package com.capg.trg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/login")
public class MyProcessRequest1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		
		
		
		// Returning values of named parameters. This data is sent from client
		// to server, thus it would be reflected using the request object
		String userid = request.getParameter("userid");
		if(userid.length()==0 || userid.equals(" "))
		{
			throw new NullPointerException();
		}
		String password = request.getParameter("password");
		try
		{
			String status=null;
			if(userid.equals("admin") && password.equals("admin@123"))
			{
				status="Hi "+userid+" Welcome...";
			}
			else
			{
				status="Invalid Credentials,";
				
			}
			request.setAttribute("status", status);//adding the req res object
			RequestDispatcher rd=request.getRequestDispatcher("views/status.jsp");
			rd.forward(request,response);
		}catch(Exception e)
		{
			response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE," Enter userid and password");
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
