package com.capg.trg.service;

import org.omg.CORBA.UserException;

import com.capg.trg.enitity.User;

public interface IUserService 
{
	User getUserDetails(Integer userid) throws UserException;
	Boolean isValidUser(String username,String password) throws UserException;
	Integer addUserDetails(User user) throws UserException;
}
