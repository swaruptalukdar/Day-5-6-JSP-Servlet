package com.capg.trg.service;

import org.omg.CORBA.UserException;

import com.capg.trg.dao.IUserDAO;
import com.capg.trg.dao.UserDAOImpl;
import com.capg.trg.enitity.User;

public class UserServiceImpl implements IUserService {
private IUserDAO userDAO=new UserDAOImpl();
	@Override
	public User getUserDetails(Integer userid) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean isValidUser(String username, String password)
			throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer addUserDetails(User user) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

}
