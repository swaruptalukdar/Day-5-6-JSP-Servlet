package com.capg.trg.exception;

public class UserException extends Exception{
private String message;

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

public UserException() {
	super();
	
}

@Override
public String toString() {
	return "UserException [message=" + message + "]";
}



}
