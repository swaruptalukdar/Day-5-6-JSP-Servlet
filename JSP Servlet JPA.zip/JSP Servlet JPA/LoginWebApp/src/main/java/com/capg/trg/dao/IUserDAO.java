package com.capg.trg.dao;



import com.capg.trg.enitity.User;
import com.capg.trg.exception.UserException;

public interface IUserDAO 
{
	User getUserDetails(Integer userid) throws UserException;
	Boolean isValidUser(String username,String password) throws UserException;
	Integer addUserDetails(User user) throws UserException;
	

}
