package com.capg.trg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyProcessRequest1
 */
@WebServlet("/myprocess")
public class MyProcessRequest1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		// Returning values of named parameters. This data is sent from client
		// to server, thus it would be reflected using the request object
		String username = request.getParameter("uname");
		String password = request.getParameter("pwd");
		Integer n=Integer.parseInt(password);
		
		if(username.equals("Swarup") && n.equals(1234))
		{
			pw.println("Welcome "+ username + " and your password= " + n);
		}
		else
			
		pw.println("else part");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
