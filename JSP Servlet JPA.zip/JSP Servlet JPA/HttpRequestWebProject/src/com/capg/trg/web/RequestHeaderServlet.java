package com.capg.trg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/requesth")
public class RequestHeaderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Enumeration reqHeaderNames=request.getHeaderNames(); 
		
		out.println("<html><body><table border='1'  bgcolor='yellow'>");
		out.println("<caption>"+"Request Header Details"+"</caption>");
		out.println("<thread><th>"+ "Request Header Name"+ "</th>");
		out.println("<th>"+ "Request Header Value"+ "</th></thead>");
		out.println("<tbody>");
		while(reqHeaderNames.hasMoreElements())
		{
			String requestHeaderName=(String) reqHeaderNames.nextElement();
			String requestHeaderValue=request.getHeader(requestHeaderName);
			out.println("<tr><td>"+requestHeaderName+"</td><td>"+requestHeaderValue+"</td></tr>");
		}
		out.println("</tbody><</table></body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
