package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class EmployeeTest {
	static Employee e1;

	@Test
	public void testGetEid() {
		assertEquals(101, e1.getEid());
	}

	@Test
	public void testGetEname() {
		String ename= e1.getEname();
		assertNotNull(ename);
		
		
	}
	@Ignore
	@Test
	public void testGetSal() {
		assertTrue(e1.getSal()>5000);
	}
	
	@BeforeClass
	public static void m1(){ 
		e1=new Employee();
	e1.setEid(101);
	e1.setEname("king");
	System.out.println("b4 every method");
		
		
		}
	
}
