import static org.junit.Assert.*;

import org.junit.Test;


public class HelloWorldTest {

	@Test
	public void testGetName() {
		//fail("Not yet implemented");
	}

	@Test
	public void testGetBalance() {
		//fail("Not yet implemented");
	}

}
