import java.util.Scanner;


public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Employee e1=new Employee();
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter your eid: ");
      int eid=sc.nextInt(); 
      e1.setEid(eid);
      System.out.println("Enter your ename: ");
      String ename=sc.next();
      e1.setEname(ename);
      
      System.out.println(e1.getEid());
      System.out.println(e1.getEname());
      System.out.println(e1.getSal());
      
      
	}

	
	
	public String getname(){ return "king";
	}
}
