import static org.junit.Assert.*;

import org.junit.Test;


public class DemoTest {
	Demo d=new Demo();
	@Test
	public void testGetname() {
		
		assertEquals("king",d.getname());
		
	}

}
