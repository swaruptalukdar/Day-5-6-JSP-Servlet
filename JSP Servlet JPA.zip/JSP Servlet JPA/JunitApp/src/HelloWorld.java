
public class HelloWorld {

	public static void main(String[] args) {
		
		HelloWorld obj=new HelloWorld();
		String name = HelloWorld.getName();
		
		int bal= obj.getBalance(1001);
		System.out.println(name+" "+bal);
	}
	
	public static String getName(){
		return "Swarup";
	}
	public int getBalance(int accountNo)
	{int bal=0;
		if(accountNo>999)
		{
			bal= 5000;
		}
		
		return bal;
	}
}
