package com.capgemini.trg.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/userc")
public class UserControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			String option=request.getParameter("option");
			String url="";
			switch(option)
			{
			case "g":
						url="views/get_id.jsp";
				break;
				
			case "u":
						url="views/get_update_id.jsp";
				break;
				
			case "d":
						url="views/get_delete_id.jsp";
				break;
				
			case "a":
						url="views/user_reg.jsp";
				break;
				
			case "s":
						url="views/show_all_users.jsp";
				break;
			default: url="login.html";
			
			}
			request.getRequestDispatcher(url).forward(request, response);
		}
		catch(Exception e)
		{
			request.getRequestDispatcher("login.jsp").forward(request, response);
			//response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE,e.getMessage());
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
